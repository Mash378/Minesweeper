1 Name: Mashroor Newaz
2 Section:
3 UFL email: mashroor.newaz@ufl.edu
4 System:Windows
5 Compiler:g++
6 SFML version:SMFL 2.5.1
7 IDE:Clion